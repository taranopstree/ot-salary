package com.opstree.microservice.salary.service;

public interface ElasticsearchRestTemplateService {

}
